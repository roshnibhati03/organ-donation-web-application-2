# ODA Architecture and Data Design

## System Architecture

```mermaid
flowchart LR
  subgraph Client[Frontend (React + Tailwind)]
    UI[Pages/Components]
    State[State Mgmt]
    APIClient[Axios]
  end

  subgraph Server[Backend (Node.js/Express)]
    Auth[Auth & JWT]
    Routes[REST API Routes]
    Match[Matching Engine]
    Val[Validation (Zod)]
    Enc[PII Encryption (AES-256-GCM)]
  end

  DB[(MongoDB)]

  UI --> APIClient -->|HTTPS/JSON| Routes
  Routes --> Auth
  Routes --> Val
  Routes --> Enc
  Routes --> Match
  Routes -->|Mongoose| DB
```

- JWT stored in httpOnly cookies (SameSite=Lax).
- PII fields encrypted at-rest with AES-256-GCM (name, phone, address, abhaId, location).
- Rate limiting, CORS, Helmet enabled.

## ER Diagram

```mermaid
erDiagram
  USER ||--o{ DONOR : "is"
  USER ||--o{ PATIENT : "is"
  DONOR ||--o{ MATCH : participates
  PATIENT ||--o{ MATCH : participates
  PATIENT ||--o{ ORGANREQUEST : submits
  FAQ ||--o{ NONE : "public"
  CAMPAIGN ||--o{ NONE : "public"
  RESOURCE ||--o{ NONE : "public"

  USER {
    string _id
    string email
    string passwordHash
    object piiEnc   "{ name, phone, abhaId, address } encrypted"
    string role     "admin|donor|patient"
    date createdAt
  }

  DONOR {
    string _id
    string userId FK
    string[] organs  "HEART,KIDNEY,LIVER,LUNG,PANCREAS,CORNEA"
    string bloodType
    object locationEnc "{ city, state } encrypted"
    string status  "active|inactive"
    date consentDate
  }

  PATIENT {
    string _id
    string userId FK
    string neededOrgan
    string bloodType
    number urgencyScore
    string status "waiting|matched|transplanted|inactive"
    date requestedAt
  }

  ORGANREQUEST {
    string _id
    string patientId FK
    string organ
    string status "waiting|matched|fulfilled|cancelled"
    number priorityScore
    date createdAt
  }

  MATCH {
    string _id
    string donorId FK
    string patientId FK
    string organ
    number score
    string status "proposed|accepted|declined|completed"
    date matchedAt
  }

  FAQ {
    string _id
    string question
    string answer
  }

  CAMPAIGN {
    string _id
    string title
    string description
    date startDate
    date endDate
  }

  RESOURCE {
    string _id
    string title
    string url
    string category
  }
```

## Collections and Schema (MongoDB)

- USER
  - email: unique
  - passwordHash: bcrypt
  - piiEnc: { name, phone, abhaId, address } encrypted payload with iv, tag, data
  - role: admin|donor|patient
  - timestamps

- DONOR
  - user: ObjectId<User>
  - organs: [enum]
  - bloodType
  - locationEnc: encrypted
  - consentDate, status
  - timestamps

- PATIENT
  - user: ObjectId<User>
  - neededOrgan: enum
  - bloodType
  - urgencyScore (0-100)
  - status
  - timestamps

- ORGANREQUEST
  - patient: ObjectId<Patient>
  - organ: enum
  - priorityScore (computed from urgency + wait time)
  - status
  - timestamps

- MATCH
  - donor: ObjectId<Donor>
  - patient: ObjectId<Patient>
  - organ
  - score
  - status
  - timestamps

- FAQ, CAMPAIGN, RESOURCE: public content.

## Matching Logic (prototype)

- Eligibility: organ match, compatible blood type, donor active, patient waiting.
- Score = urgencyScore + waitDays/7 + bloodTypeCompatibilityBonus.
- Highest score proposed first.

## Security & Privacy

- AES-256-GCM for PII at-rest. Key from `CRYPTO_SECRET`.
- JWT in httpOnly cookies, SameSite=Lax, secure in production.
- Helmet, CORS whitelist, basic rate limiting.
- Server-side validation with Zod.

## API Overview

- Auth: POST /api/auth/register, POST /api/auth/login, POST /api/auth/logout, GET /api/auth/me
- ABHA Mock: POST /api/auth/abha/verify
- Donor: GET /api/donor/me, PUT /api/donor/profile, PUT /api/donor/organs, GET /api/donor/waiting-list
- Patient: GET /api/patient/me, PUT /api/patient/profile, POST /api/patient/request, GET /api/patient/waiting-list
- Public: GET /api/faqs, /api/campaigns, /api/resources
- Admin: GET /api/admin/reports/summary

## Notes

- Replace mock ABHA verification with real integration later.
