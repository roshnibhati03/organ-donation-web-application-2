import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import App from './pages/App.jsx';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import RegisterDonor from './pages/RegisterDonor.jsx';
import RegisterPatient from './pages/RegisterPatient.jsx';
import DonorDashboard from './pages/DonorDashboard.jsx';
import PatientDashboard from './pages/PatientDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import Faqs from './pages/Faqs.jsx';
import Campaigns from './pages/Campaigns.jsx';
import Resources from './pages/Resources.jsx';

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <Home /> },
      { path: 'login', element: <Login /> },
      { path: 'register/donor', element: <RegisterDonor /> },
      { path: 'register/patient', element: <RegisterPatient /> },
      { path: 'donor', element: <DonorDashboard /> },
      { path: 'patient', element: <PatientDashboard /> },
      { path: 'admin', element: <AdminDashboard /> },
      { path: 'faqs', element: <Faqs /> },
      { path: 'campaigns', element: <Campaigns /> },
      { path: 'resources', element: <Resources /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
