import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="grid gap-8">
      <section className="bg-white border rounded-lg p-8">
        <h1 className="text-3xl font-bold mb-2">Organ Donation Application</h1>
        <p className="text-gray-600">Bridge donors and recipients with secure, transparent matching.</p>
        <div className="mt-6 flex gap-3">
          <Link to="/register/donor" className="px-4 py-2 bg-blue-600 text-white rounded">Become a Donor</Link>
          <Link to="/register/patient" className="px-4 py-2 border rounded">Register as Patient</Link>
        </div>
      </section>
      <section className="grid md:grid-cols-3 gap-4">
        <Card title="Transparent Matching" text="See waiting lists and matching criteria." />
        <Card title="Privacy by Design" text="PII encrypted at-rest. JWT in httpOnly cookies." />
        <Card title="Awareness" text="FAQs, campaigns, and resources to spread awareness." />
      </section>
    </div>
  );
}

function Card({ title, text }) {
  return (
    <div className="bg-white border rounded-lg p-6">
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 text-sm">{text}</p>
    </div>
  );
}
