import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function Campaigns() {
  const [items, setItems] = useState([]);
  useEffect(() => { (async()=>{ const { data } = await api.get('/campaigns'); setItems(data.items || []); })(); }, []);
  return (
    <div className="bg-white border rounded p-6">
      <h2 className="text-xl font-semibold mb-4">Campaigns</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {items.map(i=> (
          <div key={i._id} className="border rounded p-4">
            <div className="font-medium">{i.title}</div>
            <div className="text-gray-600 text-sm mt-1">{i.description}</div>
            <div className="text-xs text-gray-500 mt-2">{i.startDate ? new Date(i.startDate).toLocaleDateString() : ''} - {i.endDate ? new Date(i.endDate).toLocaleDateString() : ''}</div>
          </div>
        ))}
        {!items.length && <div className="text-gray-500">No campaigns yet.</div>}
      </div>
    </div>
  );
}
