import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function DonorDashboard() {
  const [me, setMe] = useState(null);
  const [waiting, setWaiting] = useState([]);
  const [organs, setOrgans] = useState([]);
  const [bloodType, setBloodType] = useState('');
  const [msg, setMsg] = useState('');

  const allOrgans = ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'];

  useEffect(() => { load(); }, []);

  async function load() {
    const { data } = await api.get('/donor/me');
    setMe(data.donor);
    setOrgans(data.donor?.organs || []);
    setBloodType(data.donor?.bloodType || '');
    const wl = await api.get('/donor/waiting-list');
    setWaiting(wl.data.waiting || []);
  }

  function toggle(o) {
    setOrgans(prev => prev.includes(o) ? prev.filter(x=>x!==o) : [...prev, o]);
  }

  async function save() {
    await api.put('/donor/organs', { organs, bloodType });
    setMsg('Saved');
    load();
    setTimeout(()=>setMsg(''), 1500);
  }

  return (
    <div className="grid gap-6">
      <section className="bg-white border rounded p-6">
        <h2 className="text-xl font-semibold mb-2">Donor Profile</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Blood Type</span>
            <input className="input" value={bloodType} onChange={e=>setBloodType(e.target.value)} />
          </label>
          <div>
            <div className="text-sm text-gray-700 mb-1">Organs</div>
            <div className="flex flex-wrap gap-2">
              {allOrgans.map(o => (
                <button type="button" key={o} onClick={()=>toggle(o)} className={`px-3 py-1 rounded border ${organs.includes(o)?'bg-blue-600 text-white':'bg-white'}`}>{o}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <button onClick={save} className="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
          {msg && <span className="text-green-700 text-sm">{msg}</span>}
        </div>
      </section>

      <section className="bg-white border rounded p-6">
        <h3 className="font-semibold mb-3">Waiting List (for your opted organs)</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="py-2">Needed Organ</th>
              <th>Blood Type</th>
              <th>Urgency</th>
              <th>Requested At</th>
            </tr>
          </thead>
          <tbody>
            {waiting.map((w) => (
              <tr key={w._id} className="border-b">
                <td className="py-2">{w.neededOrgan}</td>
                <td>{w.bloodType}</td>
                <td>{w.urgencyScore}</td>
                <td>{new Date(w.requestedAt).toLocaleString()}</td>
              </tr>
            ))}
            {!waiting.length && (
              <tr><td colSpan="4" className="text-gray-500 py-4">No patients currently waiting for your selected organs.</td></tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
