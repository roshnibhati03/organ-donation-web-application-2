import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function AdminDashboard() {
  const [report, setReport] = useState(null);

  useEffect(() => {
    (async () => {
      const { data } = await api.get('/admin/reports/summary');
      setReport(data);
    })();
  }, []);

  if (!report) return <div>Loading...</div>;

  return (
    <div className="grid gap-6">
      <section className="bg-white border rounded p-6">
        <h2 className="text-xl font-semibold mb-4">Admin Reports</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <Stat label="Users" value={report.users} />
          <Stat label="Active Donors" value={report.donors} />
          <Stat label="Patients" value={report.patients} />
          <Stat label="Waiting Requests" value={report.waitingRequests} />
          <Stat label="Matches" value={report.matches} />
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="border rounded p-4 bg-gray-50">
      <div className="text-sm text-gray-600">{label}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  );
}
