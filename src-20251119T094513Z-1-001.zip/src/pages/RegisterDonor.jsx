import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../lib/api.js';

export default function RegisterDonor() {
  const [form, setForm] = useState({ email:'', password:'', name:'', phone:'', abhaId:'', address:'', bloodType:'', organs:[] });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  function toggleOrgan(org) {
    setForm((f)=>({ ...f, organs: f.organs.includes(org) ? f.organs.filter(o=>o!==org) : [...f.organs, org] }));
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    try {
      const { data } = await api.post('/auth/register', { ...form, role: 'donor' });
      if (data.ok) navigate('/donor');
    } catch (e) { setError('Registration failed'); }
  }

  const organs = ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'];

  return (
    <div className="max-w-xl mx-auto bg-white border rounded p-6">
      <h2 className="text-xl font-semibold mb-4">Donor Registration</h2>
      {error && <div className="text-red-600 text-sm mb-2">{error}</div>}
      <form onSubmit={submit} className="grid gap-3">
        <Row label="Email"><input className="input" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></Row>
        <Row label="Password"><input type="password" className="input" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} /></Row>
        <Row label="Name"><input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></Row>
        <Row label="Phone"><input className="input" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} /></Row>
        <Row label="ABHA ID"><input className="input" value={form.abhaId} onChange={e=>setForm({...form,abhaId:e.target.value})} /></Row>
        <Row label="Address"><input className="input" value={form.address} onChange={e=>setForm({...form,address:e.target.value})} /></Row>
        <Row label="Blood Type"><input className="input" value={form.bloodType} onChange={e=>setForm({...form,bloodType:e.target.value})} /></Row>
        <div>
          <div className="text-sm font-medium mb-1">Organs to Donate</div>
          <div className="flex flex-wrap gap-2">
            {organs.map(o=> (
              <button type="button" key={o} onClick={()=>toggleOrgan(o)} className={`px-3 py-1 rounded border ${form.organs.includes(o)?'bg-blue-600 text-white':'bg-white'}`}>{o}</button>
            ))}
          </div>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Register</button>
      </form>
    </div>
  );
}

function Row({ label, children }) {
  return (
    <label className="grid gap-1">
      <span className="text-sm text-gray-700">{label}</span>
      {children}
    </label>
  );
}
