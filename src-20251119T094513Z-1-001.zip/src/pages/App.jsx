import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';

export default function App() {
  const { pathname } = useLocation();
  return (
    <div>
      <header className="border-b bg-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="text-xl font-semibold text-blue-600">ODA</Link>
          <nav className="space-x-4">
            <Link className="hover:underline" to="/faqs">FAQs</Link>
            <Link className="hover:underline" to="/campaigns">Campaigns</Link>
            <Link className="hover:underline" to="/resources">Resources</Link>
            <Link className="px-3 py-1 rounded bg-blue-600 text-white" to="/login">Login</Link>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6 min-h-[70vh]">
        <Outlet />
      </main>
      <footer className="border-t text-sm text-gray-600">
        <div className="max-w-6xl mx-auto px-4 py-6">
          © {new Date().getFullYear()} ODA · Privacy-first, secure platform.
        </div>
      </footer>
    </div>
  );
}
