import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function Faqs() {
  const [items, setItems] = useState([]);
  useEffect(() => { (async()=>{ const { data } = await api.get('/faqs'); setItems(data.items || []); })(); }, []);
  return (
    <div className="bg-white border rounded p-6">
      <h2 className="text-xl font-semibold mb-4">FAQs</h2>
      <div className="grid gap-4">
        {items.map(i=> (
          <div key={i._id} className="border rounded p-4">
            <div className="font-medium">{i.question}</div>
            <div className="text-gray-600 text-sm mt-1">{i.answer}</div>
          </div>
        ))}
        {!items.length && <div className="text-gray-500">No FAQs yet.</div>}
      </div>
    </div>
  );
}
