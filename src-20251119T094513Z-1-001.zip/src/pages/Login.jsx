import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../lib/api.js';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    setError('');
    try {
      const { data } = await api.post('/auth/login', { email, password });
      if (data.role === 'donor') navigate('/donor');
      else if (data.role === 'patient') navigate('/patient');
      else navigate('/admin');
    } catch (e) {
      setError('Login failed');
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white border rounded p-6">
      <h2 className="text-xl font-semibold mb-4">Login</h2>
      {error && <div className="text-red-600 text-sm mb-2">{error}</div>}
      <form onSubmit={submit} className="grid gap-3">
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Login</button>
      </form>
      <div className="mt-6 border-t pt-4 text-sm text-gray-700">
        <div className="mb-2">New here? Create an account:</div>
        <div className="flex gap-3">
          <Link className="px-3 py-1 border rounded hover:bg-gray-50" to="/register/donor">Sign up as Donor</Link>
          <Link className="px-3 py-1 border rounded hover:bg-gray-50" to="/register/patient">Sign up as Patient</Link>
        </div>
      </div>
    </div>
  );
}
