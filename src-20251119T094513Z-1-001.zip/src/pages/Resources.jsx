import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function Resources() {
  const [items, setItems] = useState([]);
  useEffect(() => { (async()=>{ const { data } = await api.get('/resources'); setItems(data.items || []); })(); }, []);
  return (
    <div className="bg-white border rounded p-6">
      <h2 className="text-xl font-semibold mb-4">Resources</h2>
      <div className="grid md:grid-cols-3 gap-4">
        {items.map(i=> (
          <a key={i._id} href={i.url} target="_blank" rel="noreferrer" className="border rounded p-4 block hover:bg-gray-50">
            <div className="font-medium">{i.title}</div>
            <div className="text-gray-600 text-sm mt-1">{i.category}</div>
          </a>
        ))}
        {!items.length && <div className="text-gray-500">No resources yet.</div>}
      </div>
    </div>
  );
}
