import React, { useEffect, useState } from 'react';
import api from '../lib/api.js';

export default function PatientDashboard() {
  const [me, setMe] = useState(null);
  const [waiting, setWaiting] = useState([]);
  const [neededOrgan, setNeededOrgan] = useState('');
  const [bloodType, setBloodType] = useState('');
  const [urgencyScore, setUrgencyScore] = useState(50);
  const [msg, setMsg] = useState('');

  const organs = ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'];

  useEffect(() => { load(); }, []);

  async function load() {
    const { data } = await api.get('/patient/me');
    setMe(data.patient);
    setNeededOrgan(data.patient?.neededOrgan || '');
    setBloodType(data.patient?.bloodType || '');
    setUrgencyScore(data.patient?.urgencyScore ?? 50);
    const wl = await api.get('/patient/waiting-list');
    setWaiting(wl.data.waiting || []);
  }

  async function save() {
    await api.put('/patient/profile', { neededOrgan, bloodType, urgencyScore: Number(urgencyScore) });
    setMsg('Saved');
    load();
    setTimeout(()=>setMsg(''), 1500);
  }

  async function makeRequest() {
    if (!neededOrgan) return;
    await api.post('/patient/request', { organ: neededOrgan });
    load();
  }

  return (
    <div className="grid gap-6">
      <section className="bg-white border rounded p-6">
        <h2 className="text-xl font-semibold mb-2">Patient Profile</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Needed Organ</span>
            <select className="input" value={neededOrgan} onChange={e=>setNeededOrgan(e.target.value)}>
              <option value="">Select organ</option>
              {organs.map(o=> <option key={o} value={o}>{o}</option>)}
            </select>
          </label>
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Blood Type</span>
            <input className="input" value={bloodType} onChange={e=>setBloodType(e.target.value)} />
          </label>
          <label className="grid gap-1">
            <span className="text-sm text-gray-700">Urgency Score</span>
            <input type="number" min="0" max="100" className="input" value={urgencyScore} onChange={e=>setUrgencyScore(e.target.value)} />
          </label>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <button onClick={save} className="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
          <button onClick={makeRequest} className="px-4 py-2 border rounded">Request Organ</button>
          {msg && <span className="text-green-700 text-sm">{msg}</span>}
        </div>
      </section>

      <section className="bg-white border rounded p-6">
        <h3 className="font-semibold mb-3">Waiting List (for {neededOrgan || 'selected organ'})</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="py-2">Organ</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            {waiting.map((w) => (
              <tr key={w._id} className="border-b">
                <td className="py-2">{w.organ}</td>
                <td>{w.priorityScore?.toFixed?.(2) ?? w.priorityScore}</td>
                <td>{w.status}</td>
                <td>{new Date(w.createdAt).toLocaleString()}</td>
              </tr>
            ))}
            {!waiting.length && (
              <tr><td colSpan="4" className="text-gray-500 py-4">No requests found.</td></tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
