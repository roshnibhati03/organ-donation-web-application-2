import mongoose from 'mongoose';

const ResourceSchema = new mongoose.Schema(
  {
    title: String,
    url: String,
    category: String,
  },
  { timestamps: true }
);

export default mongoose.model('Resource', ResourceSchema);
