import mongoose from 'mongoose';

const CampaignSchema = new mongoose.Schema(
  {
    title: String,
    description: String,
    startDate: Date,
    endDate: Date,
  },
  { timestamps: true }
);

export default mongoose.model('Campaign', CampaignSchema);
