import mongoose from 'mongoose';

const PatientSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    neededOrgan: { type: String, enum: ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'] },
    bloodType: String,
    urgencyScore: { type: Number, min: 0, max: 100, default: 50 },
    status: { type: String, enum: ['waiting','matched','transplanted','inactive'], default: 'waiting' },
    requestedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default mongoose.model('Patient', PatientSchema);
