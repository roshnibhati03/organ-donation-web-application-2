import mongoose from 'mongoose';

const OrganRequestSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },
    organ: { type: String, enum: ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'], required: true },
    status: { type: String, enum: ['waiting','matched','fulfilled','cancelled'], default: 'waiting' },
    priorityScore: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model('OrganRequest', OrganRequestSchema);
