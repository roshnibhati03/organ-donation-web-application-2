import mongoose from 'mongoose';

const EncryptedSchema = new mongoose.Schema(
  {
    iv: String,
    tag: String,
    data: String,
  },
  { _id: false }
);

const UserSchema = new mongoose.Schema(
  {
    email: { type: String, unique: true, required: true },
    passwordHash: { type: String, required: true },
    pii: {
      name: EncryptedSchema,
      phone: EncryptedSchema,
      abhaId: EncryptedSchema,
      address: EncryptedSchema,
    },
    role: { type: String, enum: ['admin', 'donor', 'patient'], default: 'patient' },
  },
  { timestamps: true }
);

export default mongoose.model('User', UserSchema);
