import mongoose from 'mongoose';

const EncryptedSchema = new mongoose.Schema(
  {
    iv: String,
    tag: String,
    data: String,
  },
  { _id: false }
);

const DonorSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    organs: [{
      type: String,
      enum: ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA']
    }],
    bloodType: String,
    location: EncryptedSchema,
    consentDate: Date,
    status: { type: String, enum: ['active','inactive'], default: 'active' },
  },
  { timestamps: true }
);

export default mongoose.model('Donor', DonorSchema);
