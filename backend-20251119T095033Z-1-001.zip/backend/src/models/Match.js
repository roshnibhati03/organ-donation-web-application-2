import mongoose from 'mongoose';

const MatchSchema = new mongoose.Schema(
  {
    donor: { type: mongoose.Schema.Types.ObjectId, ref: 'Donor', required: true },
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },
    organ: { type: String, enum: ['HEART','KIDNEY','LIVER','LUNG','PANCREAS','CORNEA'], required: true },
    score: { type: Number, default: 0 },
    status: { type: String, enum: ['proposed','accepted','declined','completed'], default: 'proposed' },
    matchedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default mongoose.model('Match', MatchSchema);
