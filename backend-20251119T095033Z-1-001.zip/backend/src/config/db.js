import mongoose from 'mongoose';

let dbConnected = false;
let listenersAttached = false;
let retryTimer = null;

export function isDbConnected() {
  return dbConnected;
}

function handleConnectionEvents() {
  if (listenersAttached) return;
  listenersAttached = true;
  mongoose.connection.on('connected', () => {
    dbConnected = true;
    console.log('Mongo connected');
  });
  mongoose.connection.on('disconnected', () => {
    dbConnected = false;
    console.warn('Mongo disconnected');
    queueRetry();
  });
  mongoose.connection.on('error', (err) => {
    dbConnected = false;
    console.error('Mongo error:', err?.message || err);
  });
}

export async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error('MONGODB_URI missing');
    return;
  }
  try {
    mongoose.set('strictQuery', true);
    handleConnectionEvents();
    // Redact credentials for logs
    const redacted = uri.replace(/:\S+@/, ':***@');
    console.log('Mongo connecting to', redacted);
    await mongoose.connect(uri, {
      dbName: getDbNameFromUri(uri) || 'oda',
      serverSelectionTimeoutMS: 8000,
      family: 4,
    });
  } catch (err) {
    console.error('Mongo connect failed:', err?.message || err);
    queueRetry();
  }
}

function queueRetry() {
  if (retryTimer) return;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    connectDB();
  }, 5000);
}

function getDbNameFromUri(uri) {
  try {
    const match = uri.match(/mongodb(?:\+srv)?:\/\/[^/]+\/(\w+)/);
    return match ? match[1] : null;
  } catch {
    return null;
  }
}
