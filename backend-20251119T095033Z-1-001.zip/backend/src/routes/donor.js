import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import Donor from '../models/Donor.js';
import Patient from '../models/Patient.js';

const router = express.Router();

router.use(requireAuth(['donor']));

router.get('/me', async (req, res) => {
  const donor = await Donor.findOne({ user: req.user.id }).lean();
  res.json({ donor });
});

router.put('/organs', async (req, res) => {
  const { organs, bloodType } = req.body;
  const donor = await Donor.findOneAndUpdate(
    { user: req.user.id },
    { $set: { organs: organs || [], bloodType } },
    { new: true }
  );
  res.json({ donor });
});

// Show waiting list for any organ the donor opted for
router.get('/waiting-list', async (req, res) => {
  const donor = await Donor.findOne({ user: req.user.id }).lean();
  const list = await Patient.find({ neededOrgan: { $in: donor.organs }, status: 'waiting' })
    .sort({ urgencyScore: -1, requestedAt: 1 })
    .limit(50)
    .lean();
  res.json({ waiting: list });
});

export default router;
