import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import User from '../models/User.js';
import Donor from '../models/Donor.js';
import Patient from '../models/Patient.js';
import OrganRequest from '../models/OrganRequest.js';
import Match from '../models/Match.js';

const router = express.Router();

router.use(requireAuth(['admin']));

router.get('/reports/summary', async (req, res) => {
  const [userCount, donorCount, patientCount, waitingCount, matchCount] = await Promise.all([
    User.countDocuments(),
    Donor.countDocuments({ status: 'active' }),
    Patient.countDocuments({}),
    OrganRequest.countDocuments({ status: 'waiting' }),
    Match.countDocuments({}),
  ]);
  res.json({
    users: userCount,
    donors: donorCount,
    patients: patientCount,
    waitingRequests: waitingCount,
    matches: matchCount,
  });
});

export default router;
