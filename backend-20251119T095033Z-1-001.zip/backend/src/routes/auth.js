import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Donor from '../models/Donor.js';
import Patient from '../models/Patient.js';
import { encrypt } from '../utils/crypto.js';

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { email, password, role, name, phone, abhaId, address, bloodType, organs, neededOrgan } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing credentials' });
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ error: 'Email already registered' });

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({
      email,
      passwordHash,
      pii: {
        name: encrypt(name),
        phone: encrypt(phone),
        abhaId: encrypt(abhaId),
        address: encrypt(address),
      },
      role: role === 'donor' ? 'donor' : role === 'admin' ? 'admin' : 'patient',
    });

    if (user.role === 'donor') {
      await Donor.create({ user: user._id, organs: organs || [], bloodType, consentDate: new Date() });
    } else if (user.role === 'patient') {
      await Patient.create({ user: user._id, neededOrgan, bloodType });
    }

    const token = jwt.sign({ id: user._id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.COOKIE_SECURE === 'true',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.json({ ok: true, role: user.role });
  } catch (e) {
    res.status(500).json({ error: 'Registration failed' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.COOKIE_SECURE === 'true',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.json({ ok: true, role: user.role });
  } catch (e) {
    res.status(500).json({ error: 'Login failed' });
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

router.get('/me', async (req, res) => {
  try {
    const token = req.cookies?.token;
    if (!token) return res.json({ user: null });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ user: { id: payload.id, email: payload.email, role: payload.role } });
  } catch (e) {
    res.json({ user: null });
  }
});

// Mock ABHA verification
router.post('/abha/verify', (req, res) => {
  const { abhaId } = req.body;
  if (!abhaId) return res.status(400).json({ valid: false, reason: 'Missing abhaId' });
  const valid = /^\d{14}$/.test(abhaId);
  res.json({ valid });
});

export default router;
