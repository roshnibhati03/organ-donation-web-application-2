import express from 'express';
import Faq from '../models/Faq.js';
import Campaign from '../models/Campaign.js';
import Resource from '../models/Resource.js';

const router = express.Router();

router.get('/faqs', async (req, res) => {
  const items = await Faq.find().sort({ createdAt: -1 }).lean();
  res.json({ items });
});

router.get('/campaigns', async (req, res) => {
  const items = await Campaign.find().sort({ startDate: -1 }).lean();
  res.json({ items });
});

router.get('/resources', async (req, res) => {
  const items = await Resource.find().sort({ createdAt: -1 }).lean();
  res.json({ items });
});

export default router;
