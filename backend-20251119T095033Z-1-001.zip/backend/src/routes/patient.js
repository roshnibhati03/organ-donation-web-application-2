import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import Patient from '../models/Patient.js';
import OrganRequest from '../models/OrganRequest.js';

const router = express.Router();

router.use(requireAuth(['patient']));

router.get('/me', async (req, res) => {
  const patient = await Patient.findOne({ user: req.user.id }).lean();
  res.json({ patient });
});

router.put('/profile', async (req, res) => {
  const { neededOrgan, bloodType, urgencyScore } = req.body;
  const patient = await Patient.findOneAndUpdate(
    { user: req.user.id },
    { $set: { neededOrgan, bloodType, urgencyScore } },
    { new: true }
  );
  res.json({ patient });
});

router.post('/request', async (req, res) => {
  const { organ } = req.body;
  const patient = await Patient.findOne({ user: req.user.id });
  if (!patient) return res.status(400).json({ error: 'Patient not found' });
  const priorityScore = (patient.urgencyScore || 0) + Math.max(0, (Date.now() - patient.requestedAt.getTime()) / (1000*60*60*24*7));
  const reqDoc = await OrganRequest.create({ patient: patient._id, organ, priorityScore });
  res.json({ request: reqDoc });
});

router.get('/waiting-list', async (req, res) => {
  const patient = await Patient.findOne({ user: req.user.id });
  const list = await OrganRequest.find({ organ: patient.neededOrgan, status: 'waiting' })
    .sort({ priorityScore: -1, createdAt: 1 })
    .limit(50)
    .lean();
  res.json({ waiting: list });
});

export default router;
